#include <iostream>
#include <string>
#include "base.hpp"
#include "factorybase.hpp"

using namespace std;

int main(int argc, char **argv)
{
	factorybase factory;
	Base *output = factory.parse(argv, argc);

	if (output != nullptr) {
		std::cout << output->stringify() << " = " << output->evaluate() << '\n' ; 
       }

	return 0;
}
