#ifndef __ADD_HPP_
#define __ADD_HPP_

#include "base.hpp"
#include "Op.hpp"

class Add : public Base {
	private:
		Base* leftnumber;
		Base* rightnumber;
	public:
		Add(Base* left, Base* right): leftnumber(left), rightnumber(right), Base() {}
		virtual double evaluate(){
			return (leftnumber->evaluate() + rightnumber->evaluate());
		}
		virtual std::string stringify(){
			return (leftnumber->stringify() + " + " + rightnumber->stringify());
		}
};
#endif //__ADD_HPP_
