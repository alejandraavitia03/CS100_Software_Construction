#ifndef __FACTORYTEST_HPP__
#define __FACTORYTEST_HPP__

#include "gtest/gtest.h"

//#include "Op.hpp"
//#include "Add.hpp"
//#include "Sub.hpp"
//#include "Mult.hpp"
//#include "Div.hpp"
//#include "Pow.hpp"
//#include "Rand.hpp"
#include "factorybase.hpp"

TEST(FactoryTest, add) {
    const int LENGTH = 4;
    char* test_val[LENGTH] = { "./calculator", "1,", "+", "1" };

    factorybase factory;
    Base* conversion = factory.parse(test_val, LENGTH);

    ASSERT_NE(conversion, nullptr);
    EXPECT_EQ(conversion->stringify(), "1.000000 + 1.000000");
    EXPECT_EQ(conversion->evaluate(), 2.000000);
}


/*TEST(FactoryTest, Op) {
    const int LENGTH = 2;
    char* test_val[LENGTH] = { "./calculator", "1," };

    factorybase factory;
    Base* conversion = factory.parse(test_val, LENGTH);

    EXPECT_EQ(conversion->stringify(), "1.000000");
    EXPECT_EQ(conversion->evaluate(), 1.000000);
}*/

/* TEST(FactoryTest, Pow) {
    const int LENGTH = 4;
    char* test_val[LENGTH] = { "./calculator.exe", "2", "**", "2" };
    factorybase factory;
    Base* conversion = factory.parse(test_val, LENGTH);
    ASSERT_NE(conversion, nullptr);
    EXPECT_EQ(conversion->stringify(), "2.000000 ** 2.000000");
    EXPECT_EQ(conversion->evaluate(), 4.000000);
}*/


TEST(FactoryTest, mult) {
    const int LENGTH = 4;
    char* test_val[LENGTH] = { "./calculator", "2", "*", "2" };

    factorybase factory;
    Base* conversion = factory.parse(test_val, LENGTH);

    //ASSERT_NE(conversion, nullptr);
    EXPECT_EQ(conversion->stringify(), "2.000000 * 2.000000");
    EXPECT_EQ(conversion->evaluate(), 4.000000);
}


TEST(FactoryTest, minus){
    const int LENGTH = 4;
    char* test_val[LENGTH] = { "./calculator", "4", "-", "2" };
   factorybase factory;
   Base *conversion = factory.parse(test_val, LENGTH);
   //ASSERT_NE(conversion, nullptr);
   EXPECT_EQ(conversion->stringify(), "4.000000 - 2.000000");
   EXPECT_EQ(conversion->evaluate(), 2.000000);
}

TEST(FactoryTest, combo1) {
    char* test_val[6];
    test_val[0] = "./calculator";
    test_val[1] = "1";
    test_val[2] = "+";
    test_val[3] = "1";
    test_val[4] = "*";
    test_val[5] = "2";
    factorybase factory;
    Base* conversion = factory.parse(test_val, 6);
    //ASSERT_NE(conversion, nullptr);
    EXPECT_EQ(conversion->stringify(), "1.000000 + 1.000000 * 2.000000");
    EXPECT_EQ(conversion->evaluate(), 4.000000);
}

TEST(FactoryTest, combo2) {
    char* test_val[6];
    test_val[0] = "./calculator";
    test_val[1] = "1";
    test_val[2] = "+";
    test_val[3] = "2";
    test_val[4] = "-";
    test_val[5] = "1";
    factorybase factory;
    Base* conversion = factory.parse(test_val, 6);
    //ASSERT_NE(conversion, nullptr);
    EXPECT_EQ(conversion->stringify(), "1.000000 + 2.000000 - 1.000000");
    EXPECT_EQ(conversion->evaluate(), 2.000000);
}

TEST(FactoryTest, div) {
    const int LENGTH = 4;
    char *test_val[LENGTH] ={ "./calculator", "4", "/", "2" };
    factorybase factory;
    Base* conversion = factory.parse(test_val,LENGTH);
    //ASSERT_NE(conversion, nullptr);
    EXPECT_EQ(conversion->stringify(), "4.000000 / 2.000000");
    EXPECT_EQ(conversion->evaluate(), 2.000000);
}



TEST(FactoryTest, Invalid) {
    const int LENGTH = 4;
    char* test_val[LENGTH] = { "./calculator", "1", "f", "2" };
    factorybase factory;
    Base* conversion = factory.parse(test_val, LENGTH);
    EXPECT_TRUE(conversion ==  nullptr);
}


#endif // factorytest.hpp

