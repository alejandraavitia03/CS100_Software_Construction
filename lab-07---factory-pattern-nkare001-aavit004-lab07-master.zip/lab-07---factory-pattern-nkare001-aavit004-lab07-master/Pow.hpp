#ifndef __POW_HPP__
#define __POW_HPP__

#include "base.hpp"
#include <stdexcept>
#include <limits>
#include <cmath>

class Pow: public Base{
	private:
		Base *leftNumber;
		Base *rightNumber;
	public:
		Pow(Base *left, Base *right): Base(){
			
			if(left == nullptr || right == nullptr){
				throw std::invalid_argument("Invalid Input");
			}
			
			if(left->evaluate() < 0 && !(right->evaluate() == floor(right->evaluate()))){
				throw std::invalid_argument("Imaginary Num Case");
			}
			leftNumber = left;
			rightNumber = right;
		}
		double evaluate(){
			return pow(leftNumber->evaluate(), rightNumber->evaluate());
		}
		std::string stringify(){
			return leftNumber->stringify() + " ** " + rightNumber->stringify();
		}
};
#endif 
