#ifndef __SUB_HPP_
#define __SUB_HPP_

#include "base.hpp"

class Sub: public Base {
	private:
		Base *leftnumber;
		Base *rightnumber;
	public:
		Sub(Base *left, Base*right):Base() {
			leftnumber = left;
			rightnumber = right;
		}
		double evaluate(){
			return leftnumber->evaluate() - rightnumber->evaluate();
		}
		std::string stringify(){
			return leftnumber->stringify() + " - " + rightnumber->stringify();
		}
};
#endif //__SUB_HPP_
