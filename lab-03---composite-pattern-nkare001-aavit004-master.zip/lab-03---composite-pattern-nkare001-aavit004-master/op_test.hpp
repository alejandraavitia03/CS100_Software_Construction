#ifndef __OP_TEST_HPP__
#define __OP_TEST_HPP__

#include "gtest/gtest.h"

#include "op.hpp"
#include "mult.hpp"
#include "div.hpp"
#include "rand.hpp"

TEST(OpTest, OpEvaluateNonZero) {
    Op* test = new Op(8);
    EXPECT_EQ(test->evaluate(), 8);
}

TEST(OpTest, OpEvaluateZero) 
{
	Op* test = new Op(0);
	EXPECT_EQ(test->evaluate(), 0);
}

TEST(OpTest, OpStringifyZero)
{
        Op* test = new Op(0);
        EXPECT_EQ(test->stringify(), "0.000000");
}

TEST(OpTest, OpStringifyNONZero)
{
        Op* test = new Op(3);
        EXPECT_EQ(test->stringify(), "3.000000");
}

TEST(MultTest, MultEvaluateSix)
{
Op* test_1 = new Op(3);
Op* test_2 = new Op(2);
Mult* mult = new Mult(test_1, test_2);
EXPECT_EQ(mult->evaluate(), 6);
}

TEST(MultTest, MultEvalZero)
{
	Op* test_1 = new Op(3);
	Op* test_2 = new Op(0);
	Mult* mult = new Mult(test_1, test_2);
	EXPECT_EQ(mult->evaluate(), 0);
}

TEST(MultTest, MultEvalPOSnum)
{
	Op* test_1 = new Op(3);
	Op* test_2 = new Op(4);
	Mult* mult = new Mult(test_1, test_2);
	EXPECT_EQ(mult->evaluate(), 12);
}

TEST(MultTest, MultEvalNEGnum)
{
	Op* test_1 = new Op(3);
	Op* test_2 = new Op(-1);
	Mult* mult = new Mult(test_1, test_2);
	EXPECT_EQ(mult->evaluate(), -3);
}


TEST(MultTest, MultStringPOS)
{
	Op* test_1 = new Op(3);
	Op* test_2 = new Op(2);
	Mult* mult = new Mult(test_1, test_2);
	EXPECT_EQ(mult->stringify(), "3.000000 * 2.000000");
}

TEST(MultTest, MultStringzero)
{
	Op* test_1 = new Op(3);
	Op* test_2 = new Op(0);
	Mult* mult = new Mult(test_1, test_2);
	EXPECT_EQ(mult->stringify(), "3.000000 * 0.000000");
}




TEST(DivTest, DivEvaluatepointfive)
{
Op* test_1 = new Op(2);
Op* test_2 = new Op(4);
Div* div = new Div(test_1, test_2);
EXPECT_EQ(div->evaluate(), 0.5);
}

TEST(DivTest, DivEvaluatePOSnum)
{
	Op* test_1 = new Op(4);
	Op* test_2 = new Op(2);
	Div* div = new Div(test_1, test_2);
	EXPECT_EQ(div->evaluate(), 2);
}


TEST(DivTest, DivEvaluateNEGnum)
{
	Op* test_1 = new Op(-4);
	Op* test_2 = new Op(2);
	Div* div = new Div(test_1, test_2);
	EXPECT_EQ(div->evaluate(), -2);
}

TEST(DivTest, DivStringyPOSnum)
{
	Op* test_1 = new Op(4);
	Op* test_2 = new Op(2);
	Div* div = new Div(test_1, test_2);
	EXPECT_EQ(div->stringify(), "4.000000 / 2.000000");
}

TEST(DivTest, DivStringyNEGnum)
{
	Op* test_1 = new Op(-4);
	Op* test_2 = new Op(2);
	Div* div = new Div(test_1, test_2);
	EXPECT_EQ(div->stringify(), "-4.000000 / 2.000000");
}

TEST(RandTest, RandEvaluate)
{
Rand* rand = new Rand();
double test_1 = rand->evaluate();
EXPECT_EQ(rand->evaluate(), test_1);
}

TEST(RandTest, RandStringy)
{
	Rand* rand = new Rand();
	double test_1 = rand->evaluate();
	std::string test_2 = std::to_string(test_1);
	EXPECT_EQ(rand->stringify(), test_2);
}


#endif //__OP_TEST_HPP__
