#ifndef DIV_HPP
#define DIV_HPP
#include <iostream>
#include <string>
#include "base.hpp"
using namespace std;

class Div : public Base
{

private:
        Base* leftnumber=nullptr;
        Base* rightnumber=nullptr;
public:
        Div(Base* left , Base* right)
 {
leftnumber=left;
rightnumber=right;
 }


        virtual double evaluate()
                {
                        return leftnumber->evaluate() / rightnumber->evaluate();
                }
        virtual std::string stringify()
                {
                        return leftnumber->stringify() + " / " + rightnumber->stringify();
                }
};


#endif //__DIV_HPP__
