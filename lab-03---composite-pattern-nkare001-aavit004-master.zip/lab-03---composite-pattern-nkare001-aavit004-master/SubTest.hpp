#ifndef __SUB_TEST_HPP__
#define __SUB_TEST_HPP__
#include "gtest/gtest.h"

#include "op.hpp"
#include "Sub.hpp"
#include "div.hpp"

TEST(SubTest, SubEvaluateZero){
	Op *num1 = new Op(0.0);
	Op *num2 = new Op(0.0);
	Sub *test = new Sub(num1, num2);
	EXPECT_EQ(0.0, test->evaluate());
}

TEST(SubTest, SubEvaluate){
	Op *num1 = new Op(20.0);
        Op *num2 = new Op(10.0);
        Sub *test = new Sub(num1, num2);
        EXPECT_EQ(10.0, test->evaluate());
}

TEST(SubTest, SubStringify){
        Op *num1 = new Op(20.0);
        Op *num2 = new Op(10.0);
        Sub *test = new Sub(num1, num2);
        EXPECT_EQ("(20.000000-10.000000)", test->stringify());
}
TEST(SubTest, SubNegEvaluate){
	Op *num1 = new Op(-9.0);
	Op *num2 = new Op(-12.00);
	Sub *test = new Sub(num1, num2);
	EXPECT_EQ(3.0, test->evaluate());
}

TEST(SubTest, SubNegStringify){
	Op *num1 = new Op(-9.0);
        Op *num2 = new Op(-12.0);
        Sub *test = new Sub(num1, num2);
        EXPECT_EQ("(-9.000000--12.000000)", test->stringify());
}
TEST(SubTest, SubAddEvaluate){
	Op *num1 = new Op(10.0);
	Op *num2 = new Op(2.0);
	Op *num3 = new Op(2.0);
	Add *addAnswer = new Add(num1, num2);
	Sub *test = new Sub(addAnswer, num3);
	EXPECT_EQ(10.0, test->evaluate());
}
TEST(SubTest, SubDivStringify){
        Op *num1 = new Op(10.0);
        Op *num2 = new Op(2.0);
        Op *num3 = new Op(2.0);
	Add *addAnswer = new Add(num1, num2);
        Sub *test = new Sub(addAnswer, num3);
        EXPECT_EQ("((10.000000+2.000000)-2.000000)", test->stringify());
}
#endif //__SUB_TEST_HPP__
