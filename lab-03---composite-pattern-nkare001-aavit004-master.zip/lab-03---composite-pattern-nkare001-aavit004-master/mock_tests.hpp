#ifndef __MOCK_TESTS_HPP__
#define __MOCK_TESTS_HPP__
#include "base.hpp"

class SevenOpMock: public Base {
    public:
        SevenOpMock() { }

        virtual double evaluate() { return 7.5; }
        virtual string stringify() { return "7.5"; }
};

class NegativeOpMock: public Base {
    public:
        NegativeOpMock() { }

        virtual double evaluate() { return -1; }
        virtual string stringify() { return "-1"; }
};

class ZeroOpMock: public Base {
    public:
        ZeroOpMock() { }

        virtual double evaluate() { return 0; }
        virtual string stringify() { return "0"; }
};

class BigOpMock: public Base {
    public:
        BigOpMock() { }

        virtual double evaluate() { return 99999; }
        virtual string stringify() { return "99999"; }
};

#endif //__OP_HPP__

