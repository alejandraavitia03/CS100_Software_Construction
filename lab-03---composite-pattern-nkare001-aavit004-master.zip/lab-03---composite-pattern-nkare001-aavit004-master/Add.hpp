#ifndef __ADD_HPP_
#define __ADD_HPP_

#include "base.hpp"

class Add : public Base {
	private:
		Base *leftnumber;
		Base *rightnumber;
	public:
		Add(Base *left, Base*right): Base() {
			leftnumber = left;
			rightnumber = right;
		}
		double evaluate(){
			return leftnumber->evaluate() + rightnumber->evaluate();
		}
		std::string stringify(){
			return "(" + leftnumber->stringify() + "+" + rightnumber->stringify() + ")";
		}
};
#endif //__ADD_HPP_
