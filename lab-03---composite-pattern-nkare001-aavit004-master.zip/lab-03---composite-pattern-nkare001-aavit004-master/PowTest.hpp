#ifndef __POW_TEST_HPP__
#define __POW_TEST_HPP__
#include "base.hpp"
#include "Pow.hpp"
#include "Add.hpp"
TEST(PowTest, NullExponent){
	Base *num1 = new Op(1);
	Base *exp = nullptr;
	EXPECT_THROW(Pow(num1,exp), std::invalid_argument);
	delete exp;
}
TEST(PowTest, PowEvaluate){
	Base *num1 = new Op(10);
	Base *exp = new Op(2);
	Base *test = new Pow(num1, exp);
	EXPECT_EQ(100, test->evaluate());
}
TEST(PowTest, PowStringify){
	Base *num1 = new Op(10);
        Base *exp = new Op(2);
        Base *test = new Pow(num1, exp);
        EXPECT_EQ("(10.000000**2.000000)", test->stringify());
}
#endif
