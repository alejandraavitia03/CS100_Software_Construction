#ifndef __ADD_TEST_HPP__
#define __ADD_TEST_HPP__
#include "gtest/gtest.h"

#include "op.hpp"
#include "Add.hpp"
#include "Sub.hpp"

TEST(AddTest, AddEvaluateZero){
	Op *num1 = new Op(0.0);
	Op *num2 = new Op(0.0);
	Add *test = new Add(num1, num2);
	EXPECT_EQ(0.0, test->evaluate());
}

TEST(AddTest, AddEvaluate){
	Op *num1 = new Op(20.0);
        Op *num2 = new Op(10.0);
        Add *test = new Add(num1, num2);
        EXPECT_EQ(30.0, test->evaluate());
}

TEST(AddTest, AddStringify){
        Op *num1 = new Op(20.0);
        Op *num2 = new Op(10.0);
        Add *test = new Add(num1, num2);
        EXPECT_EQ("(20.000000+10.000000)", test->stringify());
}
TEST(AddTest, AddNegEvaluate){
	Op *num1 = new Op(-9.0);
	Op *num2 = new Op(-12.00);
	Add *test = new Add(num1, num2);
	EXPECT_EQ(-21.0, test->evaluate());
}

TEST(AddTest, AddNegStringify){
	Op *num1 = new Op(-9.0);
        Op *num2 = new Op(-12.0);
        Add *test = new Add(num1, num2);
        EXPECT_EQ("(-9.000000+-12.000000)", test->stringify());
}
TEST(AddTest, SubAddEvaluate){
	Op *num1 = new Op(10.0);
	Op *num2 = new Op(1.0);
	Op *three = new Op(3.0);
	Sub *subAnswer = new Sub(num1, num2);
	Add *test = new Add(subAnswer, three);
	EXPECT_EQ(12, test->evaluate());
}
TEST(AddTest, SubAddStringify){
        Op *num1 = new Op(10.0);
        Op *num2 = new Op(1.0);
        Op *three = new Op(3.0);
        Sub *subAnswer = new Sub(num1, num2);
        Add *test = new Add(subAnswer, three);
        EXPECT_EQ("((10.000000-1.000000)+3.000000)", test->stringify());
}
#endif //__ADD_TEST_HPP__
