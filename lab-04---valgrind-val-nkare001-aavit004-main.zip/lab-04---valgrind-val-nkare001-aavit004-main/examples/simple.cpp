int main() {
    int *p = new int[10];
    p[9] = 1; //Correct this to the size - 1 = 10 - 1 = 9
	
    delete[] p; //Deallocate the memory from the new allocation
    return 0;
}
