#include <iostream>
using namespace std;

int main() {
    int x = 10; //Initializing it to something 
    cout << x << endl;

    return 0;
}
