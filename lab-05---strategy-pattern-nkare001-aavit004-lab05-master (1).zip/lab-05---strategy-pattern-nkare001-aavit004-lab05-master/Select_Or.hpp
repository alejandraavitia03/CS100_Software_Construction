#ifndef SELECT_OR_HPP
#define SELECT_OR_HPP

#include "select.hpp"

using namespace std;

class Select_Or : public Select

{
private:
    Select* select1;
    Select* select2;

public:

    Select_Or(Select* select, Select* select_)
    {
        select1 = select;
        select2 = select_;
    }

    ~Select_Or() {
        delete select1;
        delete select2;
    }

    virtual bool select(const Spreadsheet* sheet, int row) const {
        return select1->select(sheet, row) || select2->select(sheet, row);
    }


};

#endif //SELECT_OR_HPP
