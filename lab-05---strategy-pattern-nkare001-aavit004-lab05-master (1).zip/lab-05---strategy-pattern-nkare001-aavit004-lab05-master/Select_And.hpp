#ifndef SELECT_AND_HPP
#define SELECT_AND_HPP

#include "select.hpp"

using namespace std;

class Select_And : public Select{
protected:
    Select* select1;
    Select* select2;

public:

    Select_And(Select* select, Select* select_) 
    {
        select1 = select;
        select2 = select_;
    }

    ~Select_And() {
        delete select1;
        delete select2;
    }

    virtual bool select(const Spreadsheet* sheet, int row) const {
        return (select1->select(sheet, row) && select2->select(sheet, row));
    }


};



#endif 
