fndef SELECT_CONTAINS_H
#define SELECT_CONTAINS_H

#include "select.hpp"


using namespace std;

class Select_Contains : public Select_Column
{

    Spreadsheet* sheet;
    string subString;

public:
    Select_Contains(Spreadsheet* sheet, const string& columnName, const string& subString) : Select_Column(sheet, columnName)
    {
        this->sheet = sheet;
        this->subString = subString;
    }


    virtual bool select(const Spreadsheet* spreadsheet, int row)  const {
        return spreadsheet->cell_data(row, column).find(subString) != std::string::npos;

    }
    virtual bool select(const std::string& s) const {
        return true;

    }
};




#endif //SELECT_CONTAINS_H
