#ifndef SELECT_NOT_HPP
#define SELECT_NOT_HPP
using namespace std;

class Select_Not : public Select{
protected:
	Select* select1;
public:
	Select_Not(Select* select){
		select1 = select;
	}
	~Select_Not() {
		delete select1;
	}
	virtual bool select(const Spreadsheet* sheet, int row) const {
		return (!select1->select(sheet, row));
	}
	
}; 

	

#endif
